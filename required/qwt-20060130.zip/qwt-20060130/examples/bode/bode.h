#include <qmainwindow.h>
#include <qwt_plot_zoomer.h>

class BodePlot;

class MainWin : public QMainWindow
{
    Q_OBJECT

public:
    MainWin(QWidget *parent = 0);

private slots:
    void moved(const QPoint &);
    void selected(const QwtPicker::SelectedPoints &);
    
    void print();
    void exportPDF();
    void zoom(bool);

private:
    void showInfo(QString text = QString::null);

    BodePlot *d_plot;

    QwtPlotZoomer *d_zoomer[2];
    QwtPlotPicker *d_picker;
};
