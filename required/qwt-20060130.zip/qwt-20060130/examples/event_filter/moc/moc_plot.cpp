/****************************************************************************
** Meta object code from reading C++ file 'plot.h'
**
** Created: qui 14. set 14:15:19 2006
**      by: The Qt Meta Object Compiler version 59 (Qt 4.1.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../plot.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'plot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.1.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_Plot[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
       6,    5,    5,    5, 0x0a,
      39,   29,    5,    5, 0x0a,
      63,    5,    5,    5, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Plot[] = {
    "Plot\0\0setCanvasColor(QColor)\0axis,base\0insertCurve(int,double)\0"
    "scrollLeftAxis(double)\0"
};

const QMetaObject Plot::staticMetaObject = {
    { &QwtPlot::staticMetaObject, qt_meta_stringdata_Plot,
      qt_meta_data_Plot, 0 }
};

const QMetaObject *Plot::metaObject() const
{
    return &staticMetaObject;
}

void *Plot::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Plot))
	return static_cast<void*>(const_cast<Plot*>(this));
    return QwtPlot::qt_metacast(_clname);
}

int Plot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtPlot::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setCanvasColor((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 1: insertCurve((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 2: scrollLeftAxis((*reinterpret_cast< double(*)>(_a[1]))); break;
        }
        _id -= 3;
    }
    return _id;
}
